/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scenebuild;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author Rich
 */
public class User {
    private static ResultSet sqlResult;        // This the used for to link SQL calls
    
    // Data for each user instance
    int                   userId;
    int                   regionId;
    SimpleStringProperty  userName;
    SimpleStringProperty  regionName;
    SimpleStringProperty  password;

     
    // Test Constructor used during testing to pass test strings 
    User(String uName, String uRegionName, String uPassword) {
        this.userName   = new SimpleStringProperty(uName);
        this.regionName = new SimpleStringProperty(uRegionName);
        this.password   = new SimpleStringProperty(uPassword);
    }
    
    // Constructor for User with all informtion
    User(int uID, String uName, int uRegionID, String uPassword) {
        this.userId     = uID;
        this.userName   = new SimpleStringProperty(uName);
        this.regionId   = uRegionID;
        this.regionName = new SimpleStringProperty(Region.getRegionName(uRegionID));
        this.password   = new SimpleStringProperty(uPassword);
    }
    
    // Blank Constructor - creates empty user objeect
    User () {
        this.userName   = new SimpleStringProperty("No Name");
        this.regionName = new SimpleStringProperty("No Region");
        this.password   = new SimpleStringProperty("No Pass");
    }
 
    /*
    *  Read the first User from the database
    */
    int getFirstUser() {
        System.out.println("In User.GetFirstUser.");
        Connection dbConn = DBase.ConnectToDB();
        
        try {
            // Build Java SQL query statement 
            String sql = "SELECT * FROM USER"; 
            PreparedStatement dbStatement = dbConn.prepareStatement(sql);
            System.out.println("PrepareStatement complete.");
        
            // Send statement to mySQl to execute.
            System.out.println("Calling executeQuery");
            sqlResult = dbStatement.executeQuery();
            System.out.println("executeQuery complete." + sqlResult);
        } catch(Exception e){ System.out.println("DB Error" + e);}
        
        
        // Get the first user in the list
        int rc = getNextUser();
        return rc;
    }
    
    /*
    *  Read the next User from the database
    */
    int getNextUser() {
        System.out.println("In GetNextUser");

        try {
            // Read the next record from the database
            if (sqlResult.next() != true) {
                System.out.println("sqlResult Failed.  Returning 0");
                return 0;
            }
        
            // Load the data into the User object
            setUserId (sqlResult.getInt("USER_ID"));
            setUserName (sqlResult.getString("USER_NAME"));
            setPassword (sqlResult.getString("USER_PASSWORD"));
            regionId = sqlResult.getInt("REGION_ID");
            setRegionName(Region.getRegionName(regionId));
        } catch(Exception e){ System.out.println("DB Close Error" + e);}
            
        System.out.println("\nUSER_ID: " + userId);
        System.out.println("USER_NAME: " + userName);
        System.out.println("USER_PASSWORD: " + password);
        System.out.println("REGION_ID: " + regionId);
        
        return 1;  // Success
    }  

   /*
   *  Insert user into the database table
   *    - Returns the ID of the new user or 0 if error;
   */
   int InsertIntoDB() {
       int                  numRowsUpdated;
       PreparedStatement    ps;
       
       System.out.println("In User InsertIntoDB");
       Connection dbConn = DBase.ConnectToDB();
            
        try {
            // Build Java SQL prepared statement for the insert 
            String sql = "INSERT INTO USER (USER_NAME, USER_PASSWORD, REGION_ID) VALUES(?,?,?)";
            ps = dbConn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            System.out.println("PreparedStatement complete.");
            int rID = this.getRegionId();
            ps.setString(1, this.getUserName());
            ps.setString(2, this.getPassword());
            ps.setInt(3, rID);
            
            // Send statement to mySQl to execute.
            System.out.println("Calling executeUpdate");
            numRowsUpdated = ps.executeUpdate();
            System.out.println("executeUpdate complete. Result: " + numRowsUpdated);
       
            // There should be one row modified
            if (numRowsUpdated != 1) {
                System.out.println("ERROR Unexpected # of rows inserted: " + numRowsUpdated);
               return 0;
            } 
        
            // Get the UserID of the new user
            ResultSet rs = ps.getGeneratedKeys();
            if(rs != null && rs.next()){
                this.userId = rs.getInt(1);
                System.out.println("Generated User Id: " + this.userId);
            }
        } catch(Exception e){ System.out.println("DB Error: " + e.getMessage());}
        
        return this.userId;
       
   }


   /*
   *  Delete a user from the database table
   *    - Returns the number of rows deleted or 0 if error;
   */
   int deleteFromDB() {
       int                  numRowsUpdated = 0;
       PreparedStatement    ps;
       
       System.out.println("In User DeleteFromDB");
       Connection dbConn = DBase.ConnectToDB();
            
        try {
            // Build Java SQL prepared statement for the insert 
            String sql = "DELETE FROM USER WHERE USER_ID = ?";
            ps = dbConn.prepareStatement(sql);
            ps.setInt(1, this.userId);
            
            // Send statement to mySQl to execute.
            System.out.println("Calling executeUpdate");
            numRowsUpdated = ps.executeUpdate();
            System.out.println("executeUpdate complete. Result: " + numRowsUpdated);
       
            // There should be one row modified
            if (numRowsUpdated != 1) {
                System.out.println("ERROR Unexpected # of rows deleted: " + numRowsUpdated);
               return 0;
            } 
        } catch(Exception e){ System.out.println("DB Error: " + e.getMessage());}
        
        return numRowsUpdated;
       
   }

 /*
   *  Update a user's password in the database table
   *    - Returns the number of rows updated or 0 if error;
   */
   int updatePasswordInDB(String password) {
       int                  numRowsUpdated = 0;
       PreparedStatement    ps;
       
       System.out.println("In User UpdatePasswordInDB");
       Connection dbConn = DBase.ConnectToDB();
            
        try {
            // Build Java SQL prepared statement for the update 
            String sql = "UPDATE USER SET USER_PASSWORD = ? WHERE USER_ID =?";
            ps = dbConn.prepareStatement(sql);
            ps.setString(1, password);
            ps.setInt(2, this.userId);
            
            // Send statement to mySQl to execute.
            System.out.println("Calling executeUpdate");
            numRowsUpdated = ps.executeUpdate();
            System.out.println("executeUpdate complete. Result: " + numRowsUpdated);
       
            // There should be one row modified
            if (numRowsUpdated != 1) {
                System.out.println("ERROR Unexpected # of rows updated: " + numRowsUpdated);
               return 0;
            } 
        } catch (Exception e){ System.out.println("DB Error: " + e.getMessage());}
        
        return numRowsUpdated;
   }
   
    /********************************************
    * Getter and Setter
    ********************************************/
    public String getUserName() {
        return userName.get();
    }
    public void setUserName(String name) {
        userName.set(name);
    }
        
    public String getRegionName() {
        return regionName.get();
    }
    public void setRegionName(String rname) {
        regionName.set(rname);
    }
    
   
    public String getPassword() {
        return password.get();
    }
    public void setPassword(String pw) {
        password.set(pw);
    }
    
    public int getUserId() {
        return userId;
    }
    public void setUserId (int userId) { 
        this.userId =   userId;
    }

    public int getRegionId() {
        return regionId;
    }public void setRegionId(int regionId) {    
        this.regionId = regionId;
    }

    // toString
    public String toString() {
        String str =
          "USER_ID: " + userId +
          " USER_NAME: " + userName +
          " PASSWORD: " + password +
          " REGION_ID" + regionId +
          " REGION_NAME" + regionName;
        return str;
    }    
}
